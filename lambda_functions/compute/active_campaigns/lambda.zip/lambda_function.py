import os
from datetime import datetime
import boto3
import json
from campaign import Campaign

def compute_insights_functions(campaign_uuid):
    aws_lambda = boto3.client('lambda')
    payload = json.dumps({'campaign_uuid': campaign_uuid})
    aws_lambda.invoke(
        FunctionName='compute_campaign_insights_functions',
        InvocationType='Event',
        Payload=payload)

def main():
    for campaign in Campaign.active():
        compute_insights_functions(campaign)

def lambda_handler(event, context):
    main()

if __name__ == "__main__":
    main()